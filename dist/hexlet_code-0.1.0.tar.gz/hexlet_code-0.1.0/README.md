### Hexlet tests and linter status:
[![Actions Status](https://github.com/minchenkors/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/minchenkors/python-project-49/actions)

Even game asciinema https://asciinema.org/a/534994
Calc game asciinema https://asciinema.org/a/534995